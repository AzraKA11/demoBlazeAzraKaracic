package com.azra.db.tests;

import com.azra.db.pages.logInPage;
import com.azra.db.pages.storePage;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class logInTests {

    @Test
    public void logInWithValidCredentials() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        logInPage logInPage = new logInPage(driver);
        logInPage.openPage();
        logInPage.clickLogInLink();
        logInPage.setUserName("test");
        logInPage.setPassword("test");
        logInPage.clickLogInButton();


        storePage storePage = new storePage(driver);
        Assert.assertEquals(storePage.isDisplayed(), true, "Neuspješno logiranje");
        //storePage.getStoreProductItems();

    }
}

