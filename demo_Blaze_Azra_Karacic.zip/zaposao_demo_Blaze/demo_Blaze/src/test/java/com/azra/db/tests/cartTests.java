package com.azra.db.tests;

import com.azra.db.pages.cartPage;
import com.azra.db.pages.logInPage;
import com.azra.db.pages.storePage;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class cartTests {
    @Test
    public void validatePrice() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        logInPage logInPage = new logInPage(driver);
        logInPage.openPage();
        logInPage.clickLogInLink();
        logInPage.setUserName("test");
        logInPage.setPassword("test");
        logInPage.clickLogInButton();

        Thread.sleep(1000);
        storePage storePage = new storePage(driver);
        storePage.addItemToCartByName("Samsung galaxy s6");
        Thread.sleep(1000);
        Alert alert;
        alert = driver.switchTo().alert();
        alert.accept();
        Thread.sleep(1000);

        cartPage cartPage = new cartPage(driver);
        cartPage.openCartPage();
        Thread.sleep(3000);
        cartPage.getProductsData();
        String priceEquals = driver.findElement(By.xpath("/html/body/div[6]/div/div[2]/div/div/h3")).getText();

        Assert.assertEquals(cartPage.getProductsData(), Integer.parseInt(priceEquals), "Test failed");

    }
}
