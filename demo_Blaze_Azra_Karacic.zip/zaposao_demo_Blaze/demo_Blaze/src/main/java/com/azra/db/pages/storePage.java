package com.azra.db.pages;

import com.azra.db.modules.Product;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class storePage {

    public WebDriver driver;

    public storePage(WebDriver driver) {
        this.driver = driver;
    }

    public void openPage() {
        this.driver.get("https://www.demoblaze.com/index.html");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    //otvaranje korpe
    public WebElement getCart() {
        return this.driver.findElement(By.name("Cart"));
    }

    public void openCart() {

        this.driver.get("https://www.demoblaze.com/cart.html");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }
    public WebElement getItemsInCart(){


        return this.driver.findElement(By.xpath("//tbody[@id='tbodyid']"));
    }



    //vraćanje na početnu stranicu
    public WebElement getHome() {

        return this.driver.findElement(By.xpath("//*[@id=\"navbarExample\"]/ul/li[1]/a"));
    }

    public void openHome() {
        getHome().click();
    }

    //mapiranje elemenata
    public WebElement getAllItemContainer() {
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return this.driver.findElement(By.xpath("//div[@id='tbodyid']"));
    }

    public List<WebElement> getItemContainer() {
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return this.getAllItemContainer().findElements(By.xpath("//div[@class='card h-100']"));
    }

    public List<Product> getItemProperties() {

        List<Product> toReturn = new ArrayList<>();
        List<WebElement> webElementList = new ArrayList<>();
        webElementList = this.getItemContainer();
        for (int i = 0; i < webElementList.size(); i++) {
            WebElement item = webElementList.get(i);

            WebElement itemName = item.findElement(By.tagName("h4"));
            String name = itemName.getText();
            System.out.println("Imemobitela " + name);
            WebElement itemPrice = item.findElement(By.tagName("h5"));
            String price = itemPrice.getText();
            String tmpPrice = price.substring(1);
            System.out.println("Cijena" + tmpPrice);
            WebElement itemImage = item.findElement(By.xpath("//img[@class='card-img-top img-fluid']"));
            String src = itemName.getAttribute("src");

            Product product = new Product(name, Double.parseDouble(tmpPrice), src);

            toReturn.add(product);
        }
        return toReturn;
    }

    //dodavanje proizvoda u korpu
    public void addItemToCartByName(String name) throws InterruptedException {

        List<WebElement> webElementList = this.getItemContainer();
        int indexOfItem = 0;
        for (int i = 0; i < webElementList.size(); i++) {

            WebElement itemName = webElementList.get(i);

            if (itemName.findElement(By.tagName("h4")).getText().equals(name)) {
                indexOfItem = i;
                break;
            }
        }

        WebElement clickToName = webElementList.get(indexOfItem).findElement(By.tagName("h4"));
        clickToName.click();
        Thread.sleep(2000);

        WebElement clickAddtoCart = driver.findElement(By.xpath("//a[text()='Add to cart']"));
        clickAddtoCart.click();
        Thread.sleep(2000);
    }

    public boolean isDisplayed() {
        boolean toReturn = false;
        String logout = driver.findElement(By.id("logout2")).getText();
        if (driver.getPageSource().contains(logout)) {
            toReturn = true;
        }
        return toReturn;
    }


    //broj proizvoda u korpi
    public int numOfProductsInCart() {



        int toReturn;
        WebElement cart = this.getItemsInCart();
        List<WebElement> cartElements = cart.findElements(By.xpath(".//tr[@class='success']"));

        if (cartElements.size() == 0) {
            toReturn = 0;

        } else {
            toReturn = Integer.parseInt(cartElements.get(0).getText());
        }
        return toReturn;
    }
//klikanje na pop-up
    public void accept() throws InterruptedException {

        Alert alert = driver.switchTo().alert();
        String alertMessage = driver.switchTo().alert().getText();
        System.out.println("msg" + alertMessage);
        Thread.sleep(3000);
        alert.accept();

    }

    public void openCartPage() {
        this.driver.get("https://www.demoblaze.com/cart.html#");
        this.driver.manage().window().maximize();
    }

}
