package com.azra.db.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class cartPage {
    public WebDriver driver;

    public WebDriver getDriver() {
        return driver;
    }

    public void setDriver(WebDriver driver) {
        this.driver = driver;
    }


    public cartPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openCartPage() {
        this.driver.get("https://www.demoblaze.com/cart.html#");
        this.driver.manage().window().maximize();
    }


    public WebElement getProductsInCart() {
        return this.driver.findElement(By.xpath("/html/body/div[6]/div/div[1]/div/table"));

    }

    public int getProductsData() {

        List<Integer> toReturn = new ArrayList<>();

        WebElement products = getProductsInCart().findElement(By.xpath(".//tbody"));

        List<WebElement> productRow = products.findElements(By.xpath(".//tr"));

        int sum = 0;
        for (int i = 0; i < productRow.size(); i++) {

            List<WebElement> productPrice = productRow.get(i).findElements(By.xpath(".//td"));

            int j = 2;

            String price = productPrice.get(2).getText();
            sum += Double.parseDouble(price);
        }
        System.out.println("SUMA " + sum);
        return sum;
    }


}









