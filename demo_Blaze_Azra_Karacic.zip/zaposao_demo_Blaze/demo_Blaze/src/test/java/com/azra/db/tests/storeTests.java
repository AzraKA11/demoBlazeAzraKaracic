package com.azra.db.tests;

import com.azra.db.pages.logInPage;
import com.azra.db.pages.storePage;
import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class storeTests {
    @Test
    public void verifyAddtoCartByName() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        logInPage logInPage = new logInPage(driver);
        logInPage.openPage();
        logInPage.clickLogInLink();
        logInPage.setUserName("test");
        logInPage.setPassword("test");
        logInPage.clickLogInButton();


        storePage storePage = new storePage(driver);

        storePage.addItemToCartByName("Samsung galaxy s7");
        Alert alert;
        alert = driver.switchTo().alert();
        String alertMessage = driver.switchTo().alert().getText();
        System.out.println("msg" + alertMessage);
        Thread.sleep(3000);
        alert.accept();

        Assert.assertEquals(alertMessage,"Product added.","Wrong assertion.");

    }

}
