package com.azra.db.modules;

public class Product {
    private String name;
    private double price;
    private String image;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImgSource() {
        return image;
    }

    public void setImgSource(String image) {
        this.image = image;
    }


    public Product(String name, double price, String image) {
        this.name = name;
        this.price = price;
        this.image = image;
    }


}
