package com.azra.db.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

public class logInPage {

    public WebDriver driver;

    public logInPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openPage() {
        this.driver.get("https://www.demoblaze.com/");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    public WebElement logInLink() {

        return driver.findElement(By.id("login2"));
    }

    public WebElement getUserName() {
        return driver.findElement(By.id("loginusername"));
    }

    public WebElement getPassword() {

        return driver.findElement(By.id("loginpassword"));
    }

    public WebElement logInButton() {

        return driver.findElement(By.xpath("//button[text()='Log in']"));
    }


    public void clickLogInLink() {
        this.logInLink().click();

    }

    public void setUserName(String userName) throws InterruptedException {
        this.getUserName().sendKeys(userName);
        Thread.sleep(100);
    }

    public void setPassword(String password) throws InterruptedException {
        this.getPassword().sendKeys(password);
        Thread.sleep(100);
    }

    public void clickLogInButton() throws InterruptedException {
        this.logInButton().click();
        Thread.sleep(100);
    }
    public void openCartPage() {
        this.driver.get("https://www.demoblaze.com/cart.html#");
        this.driver.manage().window().maximize();
    }

}
